"""Build a completely self-contained, offline dashboard."""
from pathlib import Path
import base64
import json
import io
from PIL import Image, ImageOps, ImageEnhance, ImageFilter

ROOT = Path(__file__).resolve().parent
assets = ROOT / 'assets'

def compact_geo(filename, digits=3):
    data = json.loads((assets / filename).read_text())
    def coordinates(v):
        if isinstance(v, list):
            if v and isinstance(v[0], (int, float)):
                return [round(n, digits) for n in v]
            return [coordinates(n) for n in v]
        return v
    for f in data['features']:
        f['geometry']['coordinates'] = coordinates(f['geometry']['coordinates'])
        if filename == 'countries.json':
            f['properties'] = {'name': f['properties'].get('NAME', '')}
        else:
            f['properties'] = {k: f['properties'][k] for k in ['name', 'adcode', 'center', 'centroid'] if k in f['properties']}
    return json.dumps(data, separators=(',', ':'), ensure_ascii=False)

img = Image.open(assets / 'relief.png').convert('RGB')
gray = ImageOps.grayscale(img)
smooth = gray.filter(ImageFilter.GaussianBlur(5))
terrain = Image.new('RGB', img.size)
map_texture = Image.new('RGB', img.size)
px = terrain.load()
mp = map_texture.load()
src = img.load()
gs = gray.load()
sm = smooth.load()
def tint(value, low, high):
    v = max(0, min(255, value)) / 255
    return tuple(round(a + (b - a) * v) for a, b in zip(low, high))
for y in range(img.height):
    for x in range(img.width):
        r, g, b = src[x, y]
        detail = (gs[x, y] - sm[x, y]) * 10
        px[x, y] = tint(125 + (gs[x, y] - 225) * 2 + detail, (3, 11, 23), (51, 72, 94))
        mp[x, y] = tint(165 + (gs[x, y] - 225) * 2 + detail, (21, 89, 145), (150, 216, 251))
        if b > r + 12:
            px[x, y] = (3, 13, 27)
out = io.BytesIO()
terrain.save(out, format='WEBP', quality=86)
(assets / 'terrain.webp').write_bytes(out.getvalue())
map_out = io.BytesIO()
map_texture.save(map_out, format='WEBP', quality=89)
(assets / 'map-texture.webp').write_bytes(map_out.getvalue())
html = (ROOT / 'dashboard.template.html').read_text()
html = html.replace('/*__D3__*/', (assets / 'd3.min.js').read_text())
html = html.replace('/*__CHINA__*/', compact_geo('china.json'))
html = html.replace('/*__CHINA_OUTLINE__*/', compact_geo('china-outline.json'))
html = html.replace('/*__MAP_DEPTH__*/', (ROOT / 'map-depth.js').read_text())
html = html.replace('/*__COUNTRIES__*/', compact_geo('countries.json', 2))
html = html.replace('/*__RELIEF__*/', 'data:image/webp;base64,' + base64.b64encode(out.getvalue()).decode())
html = html.replace('/*__MAP_TEXTURE__*/', 'data:image/webp;base64,' + base64.b64encode(map_out.getvalue()).decode())
html = html.replace('/*__RELIEF_EXTENT__*/', json.dumps(json.loads((assets / 'relief-metadata.json').read_text())['extent']))
(ROOT / 'inspection.html').write_text(html)
print(f'Built inspection.html · {len(html.encode()):,} bytes · all assets embedded')
