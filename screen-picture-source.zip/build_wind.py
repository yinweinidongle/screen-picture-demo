"""Build a portable, self-contained Three.js wind power dashboard."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
html=(ROOT/'wind.template.html').read_text()
for key,path in {'/*__WIND_CSS__*/':'wind.css','/*__WIND_MODEL__*/':'wind-model.js','/*__WIND_JS__*/':'wind.js','/*__THREE__*/':'population-assets/three.min.js','/*__D3__*/':'assets/d3.min.js'}.items():
    html=html.replace(key,(ROOT/path).read_text())
assert '/*__WIND_' not in html
(ROOT/'wind.html').write_text(html)
print(f'Built wind.html: {len(html.encode()):,} bytes')
