# VIZ / LAB 大屏展厅

入口为 `home.html`，根目录 `index.html` 同样进入展厅。原巡检大屏完整保留为 `inspection.html`。

展厅包含智慧风电、智慧工厂、全国人口统计与 AI 智能巡检四个大屏。卡片中的静态预览来自实际浏览器截图，并以 WebP 内嵌，加载首页即可看到全部画面。

点击「实时预览」后，卡片内按需加载对应真实页面，支持直接操作。每次仅运行一个 iframe；关闭、筛选隐藏、滚出视野或离开页面后释放实时预览，降低 GPU 负担。卡片标题、箭头与进入按钮打开对应完整大屏。

展厅支持类型筛选、桌面双列、手机单列和键盘焦点。390 px 手机布局已验证无横向溢出。

修改 `home.template.html` / `home.css` / `home.js` 后运行 `python3 build_home.py`，脚本内嵌四张实际预览并同步生成 GitHub Pages 文件夹及 ZIP 包。

`wind.html`、`factory.html`、`population.html` 和 `inspection.html` 均为可独立打开的单文件。展厅的实时 iframe 预览建议通过 HTTP 或 GitHub Pages 使用。
