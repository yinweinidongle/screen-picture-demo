"""Embed real dashboard previews and build the local / GitHub Pages gallery."""
from pathlib import Path
from PIL import Image
import io,base64,shutil,zipfile
ROOT=Path(__file__).resolve().parent
html=(ROOT/'home.template.html').read_text()
html=html.replace('/*__HOME_CSS__*/',(ROOT/'home.css').read_text()).replace('/*__HOME_JS__*/',(ROOT/'home.js').read_text())
previews={'WIND':'wind-preview.png','FACTORY':'factory-preview.png','POPULATION':'population-preview.png','INSPECTION':'preview.png'}
for key,name in previews.items():
    im=Image.open(ROOT/name).convert('RGB');im.thumbnail((1440,810));out=io.BytesIO();im.save(out,'WEBP',quality=91,method=6)
    html=html.replace('/*__PREVIEW_'+key+'__*/','data:image/webp;base64,'+base64.b64encode(out.getvalue()).decode())
assert '/*__' not in html
(ROOT/'home.html').write_text(html)
# Preserve the inspection dashboard when making the gallery the root entry.
if not (ROOT/'inspection.html').exists():shutil.copy2(ROOT/'index.html',ROOT/'inspection.html')
(ROOT/'index.html').write_text(html)
stage=ROOT/'github-pages';stage.mkdir(exist_ok=True)
for name in ['index.html','home.html','inspection.html','population.html','factory.html','wind.html']:
    shutil.copy2(ROOT/name,stage/name)
with zipfile.ZipFile(ROOT/'github-pages.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in stage.iterdir():
        if f.is_file():z.write(f,f.name)
print(f'Built home.html + index.html: {len(html.encode()):,} bytes, 4 dashboard previews embedded')
