# 全国人口统计总览

主交付文件为 `population.html`，与巡检平台、智慧工厂两版相互独立。所有脚本、样式、地球纹理和地理数据均已内嵌，可保存为单个 HTML 使用。

## 画面

以参考图的 2160 × 1200 比例构建，自动等比例适配窗口：左侧六组人口统计面板，右侧大面积裁切的地球、中国浮起地图、冰蓝大气层、半球扫描纹理、轨道与迁徙粒子。没有将参考截图铺成背景。

地球采用 Three.js / WebGL 实时绘制。中国各省由行政区多边形三角化形成球面顶面和侧壁；外轮廓、地图纹理、城市点位与迁徙曲线均随球体旋转。图表与文字为原生 SVG/HTML 元素。为贴近参考图的视觉比例，中国地图相对地球表面作了艺术化抬升。

## 操作

- 拖动地球旋转，滚轮缩放；聚焦地球后，也可用方向键旋转、减号缩小、R 键复位。
- 左下方地图控制区：人口流动、人口分布、各省数据。
- 各省数据支持搜索、点击定位、人口结构查询和 CSV 导出。
- 点击地图省份显示数据卡片；右下角菱形按钮恢复默认视角。
- 地区环图与地图高亮联动；历年总览图例可切换显示；各面板右上角可展开详情。
- 点击日期或标题设置统计年份与显示模式。
- 左上角第一个方块暂停／恢复光效，第二个方块切换全屏。
- 按 Esc 关闭弹窗和数据卡片。

## 文件与构建

- `population.html`：单文件成品。
- `population.template.html`：页面结构。
- `population.css`：界面材质、布局与光效。
- `population.js`：统计图表、查询、筛选和数据导出。
- `population-globe.js`：三维地球、地图侧壁、大气、轨道、迁徙路径与视角控制。
- `build_population.py`：资源压缩与单文件组装。
- `population-assets/`：Three.js 与地球贴图原始素材。
- `population-preview.png`：默认视角预览。

## 新版页眉

页眉装饰已改用内置 ImageGen 文生图生成的透明背景素材，替换原先的 SVG 边框与色块。中央标题、时钟、统计设置和控制按钮仍为清晰可交互的 HTML 元素。

- `population-assets/header-background-v1.png`：生成的透明 RGBA PNG 原图。
- `population-assets/header-background-v1.webp`：保留透明通道的内嵌版本。
- `population-assets/header-prompt-v1.txt`：完整生成提示词与工具模式。
- `population-header-preview.png`：更新后的页眉局部预览。

提示词方向：透明背景、冰蓝与钛银材质、中央浅梯形标题槽、两侧细长翼轨、克制的辉光、不含文字和图标。原图未裁切或重绘，通过 CSS 进行版面取景，透明通道保留。

构建：`npm run build:population`，需要 Python 3 与 Pillow。

本地预览：`npm start`，访问 `http://127.0.0.1:5173/population.html`。也可使用支持 WebGL 的常规桌面浏览器打开 HTML 文件。内置浏览器的自动化策略限制 `file://`，本项目的浏览器检查通过本地 HTTP 预览完成；静态检查确认无外部资源依赖。

## 数据与验证

所有人口数字、比例与历史序列均为视觉展示数据，不作为官方统计依据。不同统计面板用于复刻参考图，不代表相同统计口径下的可加总数据。页面操作仅更新当前会话，刷新恢复默认。

已在浏览器检查 14 项交互，包括人口分布模式、省份搜索与联动、人口结构、地区环图、历史系列、统计详情、年份设置、光效暂停、实际地球旋转与缩放以及 CSV 实际下载；未发现脚本错误。

## 素材来源与许可

- 省界与国界：[阿里云 DataV](https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json)、[Natural Earth](https://www.naturalearthdata.com/)。
- 三维引擎：[Three.js r160](https://threejs.org/)，MIT 许可，保留原版权声明。
- 地球日间、夜间及法线纹理：[Three.js 官方示例素材](https://threejs.org/examples/textures/planets/earth_atmos_2048.jpg)。
- 图形计算：[D3.js 7.9.0](https://d3js.org/)，ISC 许可，保留原版权声明。

参考图分辨率较低，原始字体与三维项目文件不可获得；本项目用可编辑页面及地理几何重建布局、材质与主要光效。
