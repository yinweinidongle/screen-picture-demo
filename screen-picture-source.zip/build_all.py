"""Build four dashboards and then the gallery entry point."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for name in ['build.py','build_population.py','build_factory.py','build_wind.py','build_home.py']:
    subprocess.run([sys.executable,str(root/name)],cwd=root,check=True)
