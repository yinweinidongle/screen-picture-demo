# 智慧工厂可视化大屏 · 实时三维版

主交付 `factory.html` 为离线单文件，已内嵌 Three.js、D3、界面、三维建模代码与降级预览图。普通 WebGL 桌面浏览器可直接运行。公网预览：https://yinweinidongle.github.io/screen-picture-demo/factory.html 。

## 三维厂区

厂区已从渲染图片升级为实际几何模型：双曲线冷却塔的空心塔壳、双环色带、百叶与斜撑，高低锅炉厂房、厂房立面与屋面设备、管架、圆形管线、输送廊桥、储罐、办公楼、树木与道路。采用物理材质、软阴影、实例化细部与独立冷却风机动画。

- 在厂区拖动旋转，滚轮缩放，双击复位；聚焦模型后可用方向键、加减号、R 键操作。
- 点击实际建筑打开设备详情，设备参数、维护记录和暂停／恢复演示可交互。
- 厂区悬浮工具条支持缩放、参考视角、自动环绕与三维全景；全景使用同一实时画布，关闭后恢复之前视角。
- 右上角“夜色模式”切换菲涅耳轮廓光，依据视线与法线夹角计算边缘光，配合深蓝实体、极细冰蓝网格与贴近线条的柔和泛光。网格依据屏幕像素宽度抗锯齿，移除重复发光叠层；连续像素高斯模糊消除宽采样造成的重影。切入夜景与恢复日景均为 1.6 秒从左向右的着色器扫光过渡；全景内也可切换。
- 全景内“导出 GLB 模型”可下载当前建筑实体。预导出文件为 `factory-assets/factory-campus.glb`，可在兼容 glTF 2.0 的建模工具中打开。

模型按参考图的可见轮廓与布局重建。缺少原始 CAD/三维资产与背面图，无法保证与未知原模型百分之百一致；背面与不可见细部作了合理补建。

## 其余交互

保留原材料占比与计划编辑、班次生产线切换、订单查询与状态调整、订单 CSV 导出、物流和仓储详情、销售图表与控制菜单。业务数据和设备控制均为本地演示，刷新后恢复初始状态。

## 源文件与构建

- `factory.template.html` / `factory.css` / `factory.js`：大屏结构、外观与业务交互。
- `factory-model.js`：完整可编辑三维几何、材质、相机操作、点选、日夜菲涅耳扫光、泛光及 GLB 导出。
- `population-assets/three.min.js`：Three.js r160（MIT）。
- `factory-assets/factory-model.png`：上一版 ImageGen 建筑图，仅作为 WebGL 不可用时的降级画面。
- `factory-assets/factory-campus.glb`：三维建筑实体，内含材质和纹理。
- `factory-assets/grid-mask-v1.png`：ImageGen 生成的黑白网格原图，用于日景重着色与夜景网格亮度调制；原始提示词保存在 `grid-mask-prompt-v1.txt`。
- `build_factory.py`：资源内嵌与单文件生成。

`npm run build:factory` 重新生成交付 HTML，需要 Python 3 与 Pillow。`npm start` 本地预览。

## 验证

已实测实际鼠标拖动、滚轮缩放、建筑射线点选、设备暂停／恢复、全景画布迁移与关闭恢复、自动环绕、日夜双向扫光、全景夜景和 GLB 实际下载。浏览器无脚本错误。GLB 经过 Khronos glTF Validator 校验：0 错误、0 警告，包含约 29 万三角形、24 种材质与内嵌纹理。校验报告保存在 `factory-model-validation.json`。
