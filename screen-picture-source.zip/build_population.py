"""Build the population scene as an entirely self-contained offline HTML."""
from pathlib import Path
import base64
import io
import json
from PIL import Image

ROOT = Path(__file__).resolve().parent

def compact_geo(filename, digits=3):
    data = json.loads((ROOT / 'assets' / filename).read_text())
    def coords(v):
        if isinstance(v, list):
            if v and isinstance(v[0], (int, float)):
                return [round(n, digits) for n in v]
            return [coords(n) for n in v]
        return v
    for f in data['features']:
        f['geometry']['coordinates'] = coords(f['geometry']['coordinates'])
        f['properties'] = {k: f['properties'][k] for k in ['name', 'adcode', 'center', 'centroid'] if k in f['properties']}
    return json.dumps(data, ensure_ascii=False, separators=(',', ':'))

def image_uri(filename, quality):
    image = Image.open(ROOT / 'population-assets' / filename).convert('RGB')
    buf = io.BytesIO()
    image.save(buf, 'WEBP', quality=quality, method=6)
    return 'data:image/webp;base64,' + base64.b64encode(buf.getvalue()).decode()

def header_uri():
    image = Image.open(ROOT / 'population-assets/header-background-v1.png').convert('RGBA')
    alpha = image.getchannel('A')
    bounds = alpha.point(lambda a: 255 if a > 7 else 0).getbbox()
    if not bounds:
        raise ValueError('The generated header asset is empty')
    if alpha.getextrema()[0] != 0:
        raise ValueError('The generated header asset must preserve real transparency')
    # Frame the generated transparent ornament through CSS; keep its pixels intact.
    content_height = bounds[3] - bounds[1]
    scale_y = 132 / content_height
    image_height = image.height * scale_y
    image_top = -9 - bounds[1] * scale_y
    buffer = io.BytesIO()
    image.save(buffer, 'WEBP', quality=97, method=6, alpha_quality=100)
    (ROOT / 'population-assets/header-background-v1.webp').write_bytes(buffer.getvalue())
    return ('data:image/webp;base64,' + base64.b64encode(buffer.getvalue()).decode(),
            f'--header-art-top:{image_top:.2f}px;--header-art-height:{image_height:.2f}px;')

html = (ROOT / 'population.template.html').read_text()
header_image, header_style = header_uri()
html = html.replace('<header class="population-header">', f'<header class="population-header" style="{header_style}">')
replacements = {
    '/*__HEADER_ART__*/': header_image,
    '/*__POPULATION_CSS__*/': (ROOT / 'population.css').read_text(),
    '/*__POPULATION_JS__*/': (ROOT / 'population.js').read_text(),
    '/*__GLOBE_JS__*/': (ROOT / 'population-globe.js').read_text(),
    '/*__D3__*/': (ROOT / 'assets/d3.min.js').read_text(),
    '/*__THREE__*/': (ROOT / 'population-assets/three.min.js').read_text(),
    '/*__POPULATION_CHINA__*/': compact_geo('china.json'),
    '/*__POPULATION_OUTLINE__*/': compact_geo('china-outline.json'),
    '/*__POPULATION_WORLD__*/': compact_geo('countries.json', 2),
    '/*__EARTH_DAY__*/': image_uri('earth-day.jpg', 91),
    '/*__EARTH_NIGHT__*/': image_uri('earth-night.png', 90),
    '/*__EARTH_NORMAL__*/': image_uri('earth-normal.jpg', 89),
}
for marker, content in replacements.items():
    html = html.replace(marker, content)
assert '/*__POPULATION_' not in html
(ROOT / 'population.html').write_text(html)
print(f'Built population.html · {len(html.encode()):,} bytes · self-contained WebGL scene')
