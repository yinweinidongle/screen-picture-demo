"""Assemble the factory dashboard as one self-contained offline HTML file."""
from pathlib import Path
import base64
import io
from PIL import Image

ROOT = Path(__file__).resolve().parent
image = Image.open(ROOT / 'factory-assets/factory-model.png').convert('RGBA')
buffer = io.BytesIO()
image.save(buffer, 'WEBP', quality=95, method=6)
(ROOT / 'factory-assets/factory-model.webp').write_bytes(buffer.getvalue())
html = (ROOT / 'factory.template.html').read_text()
replacements = {
    '/*__FACTORY_CSS__*/': (ROOT / 'factory.css').read_text(),
    '/*__FACTORY_JS__*/': (ROOT / 'factory.js').read_text(),
    '/*__FACTORY_MODEL_JS__*/': (ROOT / 'factory-model.js').read_text(),
    '/*__FACTORY_GRID_MASK__*/': 'data:image/png;base64,' + base64.b64encode((ROOT / 'factory-assets/grid-mask-v1.png').read_bytes()).decode(),
    '/*__THREE__*/': (ROOT / 'population-assets/three.min.js').read_text(),
    '/*__D3__*/': (ROOT / 'assets/d3.min.js').read_text(),
    '/*__FACTORY_MODEL__*/': 'data:image/webp;base64,' + base64.b64encode(buffer.getvalue()).decode(),
}
for marker, content in replacements.items():
    html = html.replace(marker, content)
assert '/*__FACTORY_' not in html
(ROOT / 'factory.html').write_text(html)
print(f'Built factory.html · {len(html.encode()):,} bytes · resources embedded for offline use')
