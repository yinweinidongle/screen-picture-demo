(()=>{'use strict';
const cards=[...document.querySelectorAll('.screen-card')],filters=[...document.querySelectorAll('[data-filter]')];let active=null;
function stop(card){if(!card)return;card.querySelector('.iframe-host').replaceChildren();card.classList.remove('live','loading');const b=card.querySelector('.live-toggle');b.setAttribute('aria-pressed','false');b.innerHTML='<i></i>实时预览';if(active===card)active=null;}
function size(card){const frame=card.querySelector('iframe');if(frame)frame.style.transform=`scale(${card.querySelector('.preview-wrap').clientWidth/1920})`;}
cards.forEach(card=>{card.querySelector('.live-toggle').onclick=()=>{if(active===card){stop(card);return;}stop(active);active=card;card.classList.add('live','loading');const frame=document.createElement('iframe');frame.title=card.dataset.title+'实时预览';frame.loading='eager';frame.setAttribute('sandbox','allow-scripts allow-same-origin allow-downloads');frame.src=card.dataset.page;frame.onload=()=>{card.classList.remove('loading');size(card);};card.querySelector('.iframe-host').append(frame);size(card);const b=card.querySelector('.live-toggle');b.setAttribute('aria-pressed','true');b.innerHTML='<i></i>关闭预览';};});
filters.forEach(button=>button.onclick=()=>{stop(active);filters.forEach(b=>b.setAttribute('aria-pressed',String(b===button)));let n=0;cards.forEach(card=>{card.hidden=button.dataset.filter!=='all'&&card.dataset.category!==button.dataset.filter;if(!card.hidden)n++;});document.querySelector('#collection-count').textContent=n+' 个作品';});
new ResizeObserver(()=>{if(active)size(active);}).observe(document.querySelector('.screen-grid'));
const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(!e.isIntersecting&&active===e.target)stop(active);} ),{rootMargin:'150px'});cards.forEach(card=>observer.observe(card));
document.addEventListener('visibilitychange',()=>{if(document.hidden)stop(active);});
document.querySelector('footer>a:last-child').onclick=e=>{e.preventDefault();window.scrollTo({top:0,behavior:'smooth'});};
})();
